// Shim for extensions\core\load3d\ModelExporter.ts
export const ModelExporter = window.comfyAPI.ModelExporter.ModelExporter;
